CREATE
    DEFINER = steve@localhost FUNCTION sage_company(Company varchar(15)) RETURNS char(3)
BEGIN
	set @co = case Company 
		when 'chums' THEN 'CHI'
		when 'bc' THEN 'BCS'
        end;
RETURN @co;
END;

