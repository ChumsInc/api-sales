CREATE DEFINER = steve@localhost VIEW v_OnAllocation AS
SELECT `iw`.`company`                                                    AS `Company`,
       `iw`.`WarehouseCode`                                              AS `WarehouseCode`,
       `iw`.`ItemCode`                                                   AS `ItemCode`,
       SUM(IFNULL(`d`.`QuantityAllocated`, 0))                           AS `QuantityAllocated`,
       `iw`.`QuantityOnHand`                                             AS `QuantityOnHand`,
       (`iw`.`QuantityOnHand` - SUM(IFNULL(`d`.`QuantityAllocated`, 0))) AS `QuantityAvailable`
FROM (`c2`.`im_itemwarehouse` `iw`
     LEFT JOIN `c2`.`IM_AllocationDetail` `d`
               ON (((`iw`.`company` = `d`.`Company`) AND (`iw`.`ItemCode` = `d`.`ItemCode`) AND
                    (`iw`.`WarehouseCode` = `d`.`WarehouseCode`))))
GROUP BY `iw`.`company`, `iw`.`WarehouseCode`, `iw`.`ItemCode`;

