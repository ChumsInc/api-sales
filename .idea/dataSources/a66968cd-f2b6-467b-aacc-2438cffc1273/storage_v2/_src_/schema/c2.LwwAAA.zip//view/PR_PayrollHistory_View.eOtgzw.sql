CREATE DEFINER = steve@`%` VIEW PR_PayrollHistory_View AS
SELECT `d`.`Company`              AS `Company`,
       `d`.`EmployeeKey`          AS `EmployeeKey`,
       `d`.`CheckNo`              AS `CheckNo`,
       `d`.`HeaderSeqNo`          AS `HeaderSeqNo`,
       `d`.`DetailSeqNo`          AS `DetailSeqNo`,
       `d`.`LineType`             AS `LineType`,
       `d`.`EarningsCode`         AS `EarningsCode`,
       `d`.`EarningsType`         AS `EarningsType`,
       `d`.`EarningsDepartmentNo` AS `EarningsDepartmentNo`,
       `d`.`DeductionCode`        AS `DeductionCode`,
       `d`.`DeductionType`        AS `DeductionType`,
       `d`.`TaxStateCode`         AS `TaxStateCode`,
       `d`.`TaxProfileCode`       AS `TaxProfileCode`,
       `d`.`LaborCode`            AS `LaborCode`,
       `d`.`WorkersCompCode`      AS `WorkersCompCode`,
       `d`.`JobNo`                AS `JobNo`,
       `d`.`JobType`              AS `JobType`,
       `d`.`CostCode`             AS `CostCode`,
       `d`.`EarningsDate`         AS `EarningsDate`,
       `d`.`PayRateMultiplier`    AS `PayRateMultiplier`,
       `d`.`PayRate`              AS `PayRate`,
       `d`.`Hours`                AS `Hours`,
       `d`.`BasisAmt`             AS `BasisAmt`,
       `d`.`PayAmt`               AS `PayAmt`,
       `d`.`timestamp`            AS `timestamp`,
       `e`.`LastName`             AS `LastName`,
       `e`.`FirstName`            AS `FirstName`,
       `h`.`CheckDate`            AS `CheckDate`
FROM ((`c2`.`PR_PayrollHistoryHeader` `h` JOIN `c2`.`PR_PayrollHistoryDetail` `d` ON ((
        (`h`.`Company` = `d`.`Company`) AND (`h`.`EmployeeKey` = `d`.`EmployeeKey`) AND
        (`h`.`CheckNo` = `d`.`CheckNo`) AND (`h`.`HeaderSeqNo` = `d`.`HeaderSeqNo`))))
     JOIN `c2`.`PR_Employee` `e`
          ON (((`h`.`Company` = `e`.`Company`) AND (`h`.`EmployeeKey` = `e`.`EmployeeKey`))))
WHERE (`h`.`CheckDate` >= (NOW() - INTERVAL 2 YEAR))
ORDER BY `d`.`Company`, `d`.`EmployeeKey`, `d`.`CheckNo`, `d`.`HeaderSeqNo`, `d`.`DetailSeqNo`;

