CREATE DEFINER = steve@`%` VIEW v_QuantityOnIT AS
SELECT `od`.`Company`              AS `Company`,
       `od`.`WarehouseCode`        AS `WarehouseCode`,
       `od`.`ItemCode`             AS `ItemCode`,
       SUM(`od`.`QuantityOrdered`) AS `QuantityOrdered`
FROM (((`c2`.`PO_PurchaseOrderDetail` `od` LEFT JOIN `c2`.`PO_PurchaseOrderHeader` `oh` ON ((
        (`oh`.`Company` = `od`.`Company`) AND
        (`oh`.`PurchaseOrderNo` = `od`.`PurchaseOrderNo`)))) LEFT JOIN `c2`.`ci_item` `i` ON ((
        (`i`.`company` = `od`.`Company`) AND (`i`.`ItemCode` = `od`.`ItemCode`))))
     LEFT JOIN `c2`.`im_itemvendor` `iv`
               ON (((`iv`.`company` = `i`.`company`) AND (`iv`.`ItemCode` = `i`.`ItemCode`) AND
                    (`iv`.`VendorNo` = `i`.`PrimaryVendorNo`))))
WHERE ((`i`.`ItemType` = 1) AND (`oh`.`OrderType` = 'X') AND
       (`oh`.`RequiredExpireDate` <= (NOW() + INTERVAL LEAST(IFNULL(`iv`.`StandardLeadTime`, 0), 14) DAY)))
GROUP BY `od`.`Company`, `od`.`ItemCode`, `od`.`WarehouseCode`;

