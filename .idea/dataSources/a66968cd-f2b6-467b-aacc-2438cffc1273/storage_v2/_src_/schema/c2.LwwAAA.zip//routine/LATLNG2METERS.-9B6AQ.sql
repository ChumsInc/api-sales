CREATE
    DEFINER = steve@`%` FUNCTION LATLNG2METERS(lat1 decimal(10, 8), lng1 decimal(11, 8), lat2 decimal(10, 8),
                                               lng2 decimal(11, 8)) RETURNS int
BEGIN
  set @radius = 6371000;
  set @x = ACOS((SIN(RADIANS(lat1)) * SIN(RADIANS(lat2))) + (COS(RADIANS(lat1)) * COS(RADIANS(lat2)) * COS(ABS(RADIANS(lng2) - RADIANS(lng1)))));
  RETURN ROUND(@radius * @x);
END;

