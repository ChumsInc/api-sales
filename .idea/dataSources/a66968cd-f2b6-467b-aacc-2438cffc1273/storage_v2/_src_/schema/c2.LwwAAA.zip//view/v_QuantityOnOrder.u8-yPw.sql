CREATE DEFINER = steve@`%` VIEW v_QuantityOnOrder AS
SELECT `od`.`Company`                                                                          AS `Company`,
       `od`.`WarehouseCode`                                                                    AS `WarehouseCode`,
       `od`.`ItemCode`                                                                         AS `ItemCode`,
       SUM((`od`.`QuantityOrdered` - `od`.`QuantityShipped`) * `od`.`UnitOfMeasureConvFactor`) AS `QuantityOrdered`
FROM (((`c2`.`SO_SalesOrderDetail` `od` JOIN `c2`.`SO_SalesOrderHeader` `oh` ON (`oh`.`Company` = `od`.`Company` AND
                                                                                 `oh`.`SalesOrderNo` = `od`.`SalesOrderNo`)) JOIN `c2`.`ci_item` `i` ON (`i`.`company` = `od`.`Company` AND `i`.`ItemCode` = `od`.`ItemCode`))
     LEFT JOIN `c2`.`im_itemvendor` `iv`
               ON (`iv`.`company` = `i`.`company` AND `iv`.`ItemCode` = `i`.`ItemCode` AND
                   `iv`.`VendorNo` = `i`.`PrimaryVendorNo`))
WHERE `i`.`ItemType` = 1
  AND `oh`.`OrderType` IN ('B', 'S')
  AND `oh`.`ShipExpireDate` <=
      CURRENT_TIMESTAMP() + INTERVAL IF(`i`.`PlannerCode` = 'SLC', 7, LEAST(IFNULL(`iv`.`StandardLeadTime`, 0), 14)) DAY
GROUP BY `od`.`Company`, `od`.`ItemCode`, `od`.`WarehouseCode`;

