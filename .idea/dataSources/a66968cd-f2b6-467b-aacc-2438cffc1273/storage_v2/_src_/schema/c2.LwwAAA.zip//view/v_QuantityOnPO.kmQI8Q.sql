CREATE DEFINER = steve@localhost VIEW v_QuantityOnPO AS
SELECT `i`.`company`                                       AS `Company`,
       `i`.`ItemCode`                                      AS `ItemCode`,
       `d`.`WarehouseCode`                                 AS `WarehouseCode`,
       SUM(`d`.`QuantityOrdered` - `d`.`QuantityReceived`) AS `QtyOnPO`
FROM (((`c2`.`ci_item` `i` JOIN `c2`.`PO_PurchaseOrderDetail` `d` ON (`d`.`Company` = `i`.`company` AND
                                                                      CONVERT(`d`.`ItemCode` USING utf8) = `i`.`ItemCode`)) JOIN `c2`.`PO_PurchaseOrderHeader` `h` ON (
        `h`.`Company` = `d`.`Company` AND `h`.`PurchaseOrderNo` = `d`.`PurchaseOrderNo`))
     LEFT JOIN `c2`.`im_itemvendor` `iv`
               ON (`iv`.`company` = `i`.`company` AND `iv`.`ItemCode` = `i`.`ItemCode` AND
                   `iv`.`VendorNo` = `i`.`PrimaryVendorNo`))
WHERE `i`.`ItemType` = '1'
  AND `h`.`OrderType` <> 'X'
  AND `i`.`ProductType` NOT IN ('D', 'R')
  AND `i`.`ProductLine` <> 'FGRM'
  AND `d`.`RequiredDate` <= CURRENT_TIMESTAMP() + INTERVAL LEAST(IFNULL(`iv`.`StandardLeadTime`, 0), 14) DAY
GROUP BY `i`.`company`, `i`.`ItemCode`;

