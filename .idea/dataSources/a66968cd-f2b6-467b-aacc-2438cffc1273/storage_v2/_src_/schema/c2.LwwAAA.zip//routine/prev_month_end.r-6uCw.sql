CREATE
    DEFINER = steve@`%` FUNCTION prev_month_end() RETURNS date DETERMINISTIC NO SQL
    RETURN LAST_DAY(now() - interval 1 month);

