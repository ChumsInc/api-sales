CREATE
    DEFINER = steve@`%` FUNCTION prev_month_end() RETURNS date
    RETURN LAST_DAY(now() - interval 1 month);

