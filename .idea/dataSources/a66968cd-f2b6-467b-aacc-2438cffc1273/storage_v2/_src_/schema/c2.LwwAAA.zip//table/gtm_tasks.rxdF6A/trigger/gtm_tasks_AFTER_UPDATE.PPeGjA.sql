CREATE DEFINER = root@localhost TRIGGER gtm_tasks_AFTER_UPDATE
    AFTER UPDATE
    ON gtm_tasks
    FOR EACH ROW
BEGIN
	INSERT INTO c2.gtm_tasks_history (action, id, season_id, department_id, label, status, startDate, endDate, user_id, timestamp)
    VALUES ('update', NEW.id, NEW.season_id, NEW.department_id, NEW.label, NEW.status, NEW.startDate, NEW.endDate, NEW.user_id, NEW.timestamp);
END;

