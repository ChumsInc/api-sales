CREATE DEFINER = steve@`%` VIEW v_web_available AS
SELECT `i`.`company`                                                            AS `Company`,
       `i`.`ItemCode`                                                           AS `ItemCode`,
       `i`.`ItemCodeDesc`                                                       AS `ItemCodeDesc`,
       `i`.`DefaultWarehouseCode`                                               AS `DefaultWarehouseCode`,
       `i`.`ProductLine`                                                        AS `ProductLine`,
       `iw`.`WarehouseCode`                                                     AS `WarehouseCode`,
       `iw`.`QuantityOnHand`                                                    AS `QuantityOnHand`,
       IFNULL(`qo`.`QtyOnOrder`, 0)                                             AS `QuantityOrdered`,
       `wb`.`buffer`                                                            AS `buffer`,
       `wb`.`id`                                                                AS `buffer_id`,
       IFNULL(`qw`.`QtyRequiredForWO`, 0)                                       AS `QtyRequiredForWO`,
       IFNULL(`it`.`QuantityOrdered`, 0)                                        AS `QuantityOnIT`,
       IF((`i`.`InactiveItem` = 'Y'), 0, (`iw`.`QuantityOnHand` -
                                          (((IFNULL(`qo`.`QtyOnOrder`, 0) + IFNULL(`wb`.`buffer`, 0)) +
                                            IFNULL(`qw`.`QtyRequiredForWO`, 0)) +
                                           IFNULL(`it`.`QuantityOrdered`, 0)))) AS `QuantityAvailable`,
       `i`.`ProductType`                                                        AS `ProductType`,
       `iw2`.`ItemStatus`                                                       AS `ItemStatus`,
       `i`.`InactiveItem`                                                       AS `InactiveItem`
FROM ((((((`c2`.`ci_item` `i` JOIN `c2`.`im_itemwarehouse` `iw` ON (((`iw`.`company` = `i`.`company`) AND
                                                                     (`iw`.`ItemCode` = `i`.`ItemCode`)))) LEFT JOIN `c2`.`web_QtyOnOrder` `qo` ON ((
        (`qo`.`Company` = `iw`.`company`) AND (`qo`.`WarehouseCode` = `iw`.`WarehouseCode`) AND
        (`qo`.`ItemCode` = `iw`.`ItemCode`)))) LEFT JOIN `c2`.`web_buffers` `wb` ON ((
        (`wb`.`Company` = `iw`.`company`) AND (`wb`.`ItemCode` = `iw`.`ItemCode`) AND
        (`wb`.`WarehouseCode` = `iw`.`WarehouseCode`)))) LEFT JOIN `c2`.`web_RequiredForWO` `qw` ON ((
        (`qw`.`Company` = `i`.`company`) AND (`qw`.`ItemCode` = `i`.`ItemCode`) AND
        (`qw`.`WarehouseCode` = `i`.`DefaultWarehouseCode`)))) LEFT JOIN `c2`.`v_QuantityOnIT` `it` ON ((
        (`it`.`Company` = `i`.`company`) AND (`it`.`ItemCode` = `i`.`ItemCode`) AND
        (`it`.`WarehouseCode` = `i`.`DefaultWarehouseCode`))))
     LEFT JOIN `c2`.`IM_ItemWarehouseAdditional` `iw2`
               ON (((`iw2`.`company` = `iw`.`company`) AND (`iw2`.`ItemCode` = `iw`.`ItemCode`) AND
                    (`iw2`.`WarehouseCode` = `iw`.`WarehouseCode`))))
WHERE ((`iw`.`WarehouseCode` = `i`.`DefaultWarehouseCode`) OR (`wb`.`WarehouseCode` <> `i`.`DefaultWarehouseCode`));

