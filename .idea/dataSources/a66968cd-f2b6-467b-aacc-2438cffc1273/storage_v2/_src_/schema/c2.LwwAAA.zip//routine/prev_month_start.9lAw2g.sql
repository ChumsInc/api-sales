CREATE
    DEFINER = steve@`%` FUNCTION prev_month_start() RETURNS date DETERMINISTIC NO SQL
    RETURN str_to_date(concat_ws('-',year(now() - interval 1 month),monthname(now() - interval 1 month), '01'), "%Y-%M-%d");

