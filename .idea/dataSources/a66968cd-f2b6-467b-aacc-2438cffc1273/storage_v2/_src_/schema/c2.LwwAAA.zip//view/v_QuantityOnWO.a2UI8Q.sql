CREATE DEFINER = steve@localhost VIEW v_QuantityOnWO AS
SELECT `i`.`company`                               AS `Company`,
       `i`.`ItemCode`                              AS `ItemCode`,
       `m`.`ParentWhse`                            AS `WarehouseCode`,
       SUM((`m`.`QtyOrdered` - `m`.`QtyComplete`)) AS `QtyOnWO`
FROM ((`c2`.`ci_item` `i` JOIN `c2`.`wo_master_current` `m` ON (((CONVERT(`m`.`Company` USING utf8) = `i`.`company`) AND
                                                                 (CONVERT(`m`.`ItemBillNumber` USING utf8) = `i`.`ItemCode`) AND
                                                                 (`m`.`Status` <> 'C'))))
     LEFT JOIN `c2`.`im_itemvendor` `iv`
               ON (((`iv`.`company` = `i`.`company`) AND (`iv`.`ItemCode` = `i`.`ItemCode`) AND
                    (`iv`.`VendorNo` = `i`.`PrimaryVendorNo`))))
WHERE ((`i`.`ItemType` = '1') AND (`i`.`ProductType` NOT IN ('D', 'R')) AND (`i`.`ProductLine` <> 'FGRM') AND
       (`m`.`WODueDate` <= (NOW() + INTERVAL LEAST(IFNULL(`iv`.`StandardLeadTime`, 0), 14) DAY)))
GROUP BY `i`.`company`, `i`.`ItemCode`;

