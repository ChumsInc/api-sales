CREATE DEFINER = steve@`%` TRIGGER AZ_SalesOrderLog_AFTER_UPDATE
    AFTER UPDATE
    ON AZ_SalesOrderLog
    FOR EACH ROW
BEGIN
	INSERT INTO c2.AZ_SalesOrderHistory (Company, dbCompany, SalesOrderNo, AmazonOrderId, OrderStatus, Notes, data, UserID, action, original_timestamp)
    VALUES (OLD.Company, b2b.dbCompany(OLD.Company), OLD.SalesOrderNo, OLD.AmazonOrderId, OLD.OrderStatus, OLD.Notes, OLD.data, OLD.UserID, OLD.action, OLD.timestamp);
END;

