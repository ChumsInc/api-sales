CREATE DEFINER = root@localhost TRIGGER gtm_tasks_BEFORE_DELETE
    BEFORE DELETE
    ON gtm_tasks
    FOR EACH ROW
BEGIN
	INSERT INTO c2.gtm_tasks_history (action, id, season_id, department_id, label, status, startDate, endDate, user_id, timestamp)
    VALUES ('delete', OLD.id, OLD.season_id, OLD.department_id, OLD.label, OLD.status, OLD.startDate, OLD.endDate, OLD.user_id, OLD.timestamp);
END;

