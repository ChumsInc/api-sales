CREATE DEFINER = steve@`%` VIEW IM_KitComponentCost AS
SELECT `iw`.`company`                                    AS `Company`,
       `iw`.`ItemCode`                                   AS `ItemCode`,
       `iw`.`WarehouseCode`                              AS `WarehouseCode`,
       SUM(`bd`.`QuantityPerBill` * `iwc`.`AverageCost`) AS `AverageCost`
FROM ((((`c2`.`ci_item` `i` JOIN `c2`.`im_itemwarehouse` `iw` ON (`iw`.`company` = `i`.`company` AND `iw`.`ItemCode` = `i`.`ItemCode`)) JOIN `c2`.`BM_BillHeader` `bh` ON (`bh`.`Company` = `iw`.`company` AND `bh`.`BillNo` = `iw`.`ItemCode`)) JOIN `c2`.`BM_BillDetail` `bd` ON (
        `bd`.`Company` = `bh`.`Company` AND `bd`.`BillNo` = `bh`.`BillNo` AND `bd`.`Revision` = `bh`.`Revision`))
     JOIN `c2`.`im_itemwarehouse` `iwc`
          ON (`iwc`.`company` = `bd`.`Company` AND `iwc`.`ItemCode` = `bd`.`ComponentItemCode` AND
              `iwc`.`WarehouseCode` = `iw`.`WarehouseCode`))
WHERE `i`.`InactiveItem` <> 'Y'
  AND `i`.`ProductType` = 'K'
GROUP BY `iw`.`company`, `iw`.`ItemCode`, `iw`.`WarehouseCode`;

