CREATE
    DEFINER = steve@localhost FUNCTION dbCompany(SageCompany varchar(3)) RETURNS varchar(5) DETERMINISTIC
BEGIN
	declare company varchar(5) default SageCompany;
    
    case SageCompany
		when 'CHI' then select 'chums' into company;
		when 'BCS' then select 'bc' into company;	
        else 
			begin
				select SageCompany into company;
            end;
	end case;
RETURN company;
END;

