CREATE VIEW v_SalesOrderHistory_company AS
SELECT `h`.`id`                         AS `id`,
       `b2b`.`dbCompany`(`h`.`Company`) AS `Company`,
       `h`.`SalesOrderNo`               AS `SalesOrderNo`,
       `h`.`OrderStatus`                AS `OrderStatus`,
       `h`.`Notes`                      AS `Notes`,
       `h`.`PaymentData`                AS `PaymentData`,
       `h`.`UserID`                     AS `UserID`,
       `h`.`action`                     AS `action`,
       `h`.`original_timestamp`         AS `original_timestamp`,
       `h`.`timestamp`                  AS `timestamp`
FROM `b2b`.`SalesOrderHistory` `h`;

