CREATE DEFINER = steve@`%` VIEW SalesOrderPromoteLog AS
SELECT DISTINCT `b2b`.`SalesOrderLog`.`dbCompany`    AS `dbCompany`,
                `b2b`.`SalesOrderLog`.`SalesOrderNo` AS `SalesOrderNo`,
                `b2b`.`SalesOrderLog`.`UserID`       AS `UserID`
FROM `b2b`.`SalesOrderLog`
WHERE `b2b`.`SalesOrderLog`.`dbCompany` IN ('chums', 'bc')
  AND `b2b`.`SalesOrderLog`.`action` REGEXP '"action":"promote"'
UNION
SELECT DISTINCT `b2b`.`SalesOrderHistory`.`dbCompany`    AS `dbCompany`,
                `b2b`.`SalesOrderHistory`.`SalesOrderNo` AS `SalesOrderNo`,
                `b2b`.`SalesOrderHistory`.`UserID`       AS `UserID`
FROM `b2b`.`SalesOrderHistory`
WHERE `b2b`.`SalesOrderHistory`.`dbCompany` IN ('chums', 'bc')
  AND `b2b`.`SalesOrderHistory`.`action` REGEXP '"action":"promote"'
GROUP BY `b2b`.`SalesOrderHistory`.`dbCompany`, `b2b`.`SalesOrderHistory`.`SalesOrderNo`;

