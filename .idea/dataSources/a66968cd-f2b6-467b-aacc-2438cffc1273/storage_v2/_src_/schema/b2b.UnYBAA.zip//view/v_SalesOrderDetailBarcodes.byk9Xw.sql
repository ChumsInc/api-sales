CREATE DEFINER = steve@`%` VIEW v_SalesOrderDetailBarcodes AS
SELECT `h`.`Company`              AS `Company`,
       `h`.`SalesOrderNo`         AS `SalesOrderNo`,
       `d`.`ItemCode`             AS `ItemCode`,
       `h`.`ARDivisionNo`         AS `ARDivisionNo`,
       `h`.`CustomerNo`           AS `CustomerNo`,
       `h`.`BillToName`           AS `BillToName`,
       `h`.`ShipToName`           AS `ShipToName`,
       `h`.`ShipToAddress1`       AS `ShipToAddress1`,
       `h`.`ShipToAddress2`       AS `ShipToAddress2`,
       `h`.`ShipToAddress3`       AS `ShipToAddress3`,
       `h`.`ShipToCity`           AS `ShipToCity`,
       `h`.`ShipToState`          AS `ShipToState`,
       `h`.`ShipToZipCode`        AS `ShipToZipCode`,
       `h`.`CustomerPONo`         AS `CustomerPONo`,
       `d`.`QuantityOrdered`      AS `QuantityOrdered`,
       `i`.`SuggestedRetailPrice` AS `SuggestedRetailPrice`,
       `i`.`UDF_UPC`              AS `UDF_UPC`,
       `i`.`UDF_UPC_BY_COLOR`     AS `UDF_UPC_BY_COLOR`,
       `i`.`UDF_COUNTRY_ORIGIN`   AS `UDF_COUNTRY_ORIGIN`,
       `b`.`AltItemNumber`        AS `AltItemNumber`,
       `b`.`ItemDescription`      AS `ItemDescription`,
       `b`.`Color`                AS `Color`,
       `b`.`SKU`                  AS `SKU`,
       `b`.`CustomerPart`         AS `CustomerPart`,
       `b`.`UPC`                  AS `UPC`,
       `b`.`MSRP`                 AS `MSRP`,
       `b`.`Custom1`              AS `Custom1`,
       `b`.`Custom2`              AS `Custom2`,
       `b`.`Custom3`              AS `Custom3`,
       `b`.`Custom4`              AS `Custom4`
FROM ((((`c2`.`SO_SalesOrderHeader` `h` JOIN `c2`.`SO_SalesOrderDetail` `d` ON (((`d`.`Company` = `h`.`Company`) AND
                                                                                 (`d`.`SalesOrderNo` = `h`.`SalesOrderNo`)))) JOIN `c2`.`ci_item` `i` ON (((`i`.`company` = `d`.`Company`) AND (`i`.`ItemCode` = `d`.`ItemCode`)))) JOIN `barcodes`.`bc_customer` `c` ON ((
        (`c`.`Company` = `h`.`Company`) AND (`c`.`ARDivisionNo` = `h`.`ARDivisionNo`) AND
        (`c`.`CustomerNo` = `h`.`CustomerNo`))))
     LEFT JOIN `barcodes`.`bc_customerdetail` `b`
               ON (((`b`.`CustomerID` = `c`.`id`) AND (`b`.`Company` = `d`.`Company`) AND
                    (`b`.`ItemNumber` = `d`.`ItemCode`))))
WHERE (`d`.`ItemType` = '1');

