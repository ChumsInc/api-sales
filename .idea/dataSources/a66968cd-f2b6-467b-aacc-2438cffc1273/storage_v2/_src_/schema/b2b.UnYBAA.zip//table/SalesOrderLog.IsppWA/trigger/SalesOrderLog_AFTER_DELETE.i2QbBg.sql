CREATE DEFINER = steve@`%` TRIGGER SalesOrderLog_AFTER_DELETE
    AFTER DELETE
    ON SalesOrderLog
    FOR EACH ROW
BEGIN
	INSERT INTO b2b.SalesOrderHistory (Company, dbCompany, SalesOrderNo, OrderStatus, Notes, PaymentData, UserID, action, original_timestamp)
    VALUES (OLD.Company, b2b.dbCompany(OLD.Company), OLD.SalesOrderNo, OLD.OrderStatus, OLD.Notes, OLD.PaymentData, OLD.UserID, OLD.action, OLD.timestamp),
        (OLD.Company, b2b.dbCompany(OLD.Company), OLD.SalesOrderNo, OLD.OrderStatus, '', '', OLD.UserID, 'delete', NOW());
END;

