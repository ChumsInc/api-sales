CREATE VIEW user_Account AS
SELECT `user_AR_Customer`.`userid`       AS `userid`,
       `user_AR_Customer`.`api_id`       AS `api_id`,
       `user_AR_Customer`.`Company`      AS `Company`,
       `user_AR_Customer`.`ARDivisionNo` AS `ARDivisionNo`,
       `user_AR_Customer`.`CustomerNo`   AS `CustomerNo`,
       `user_AR_Customer`.`ShipToCode`   AS `ShipToCode`
FROM `users`.`user_AR_Customer`
UNION
SELECT `user_SO_ShipToAddress`.`userid`       AS `userid`,
       `user_SO_ShipToAddress`.`api_id`       AS `api_id`,
       `user_SO_ShipToAddress`.`Company`      AS `Company`,
       `user_SO_ShipToAddress`.`ARDivisionNo` AS `ARDivisionNo`,
       `user_SO_ShipToAddress`.`CustomerNo`   AS `CustomerNo`,
       `user_SO_ShipToAddress`.`ShipToCode`   AS `ShipToCode`
FROM `users`.`user_SO_ShipToAddress`;

