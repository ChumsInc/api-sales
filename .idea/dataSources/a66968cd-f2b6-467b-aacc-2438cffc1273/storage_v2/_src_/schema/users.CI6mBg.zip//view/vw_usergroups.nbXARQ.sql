CREATE DEFINER = steve@`%` VIEW vw_usergroups AS
SELECT `u`.`id` AS `userid`, `u`.`name` AS `name`, `u`.`email` AS `email`, `g`.`id` AS `groupid`, `g`.`role` AS `role`
FROM ((`users`.`users` `u` JOIN `users`.`member` `m` ON ((`m`.`userid` = `u`.`id`)))
     JOIN `users`.`groups` `g`
          ON ((`g`.`id` = `m`.`groupid`)))
WHERE (`u`.`active` = 1);

