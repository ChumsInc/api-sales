CREATE VIEW user_accounts AS
SELECT `a`.`id`                                               AS `id`,
       `a`.`userid`                                           AS `userid`,
       `a`.`Company`                                          AS `Company`,
       `a`.`ARDivisionNo`                                     AS `ARDivisionNo`,
       `a`.`CustomerNo`                                       AS `CustomerNo`,
       `a`.`isRepAccount`                                     AS `isRepAccount`,
       `a`.`SalespersonDivisionNo`                            AS `SalespersonDivisionNo`,
       `a`.`SalespersonNo`                                    AS `SalespersonNo`,
       `c`.`CustomerName`                                     AS `CustomerName`,
       IFNULL(`s`.`SalespersonName`, 'Multiple Rep Accounts') AS `SalespersonName`
FROM ((`users`.`accounts` `a` LEFT JOIN `c2`.`ar_customer` `c` ON (((`c`.`Company` = `a`.`Company`) AND
                                                                    (`c`.`ARDivisionNo` = `a`.`ARDivisionNo`) AND
                                                                    (`a`.`CustomerNo` = `c`.`CustomerNo`))))
     LEFT JOIN `c2`.`ar_salesperson` `s`
               ON (((`s`.`Company` = `a`.`Company`) AND (`s`.`SalespersonDivisionNo` = `a`.`SalespersonDivisionNo`) AND
                    (`s`.`SalespersonNo` = `a`.`SalespersonNo`))))
ORDER BY `a`.`isRepAccount` DESC, `a`.`Company`, `a`.`ARDivisionNo`, `a`.`CustomerNo`;

