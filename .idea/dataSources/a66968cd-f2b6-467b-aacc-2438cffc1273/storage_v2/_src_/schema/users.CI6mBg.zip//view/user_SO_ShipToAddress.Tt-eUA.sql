CREATE DEFINER = steve@localhost VIEW user_SO_ShipToAddress AS
SELECT IFNULL(`a`.`userid`, 0)     AS `userid`,
       IFNULL(`a`.`api_id`, 0)     AS `api_id`,
       `c`.`Company`               AS `Company`,
       `c`.`ARDivisionNo`          AS `ARDivisionNo`,
       `c`.`CustomerNo`            AS `CustomerNo`,
       `ac`.`CustomerName`         AS `CustomerName`,
       `ac`.`CustomerStatus`       AS `CustomerStatus`,
       `c`.`ShipToCode`            AS `ShipToCode`,
       `c`.`ShipToName`            AS `ShipToName`,
       `c`.`ShipToAddress1`        AS `ShipToAddress1`,
       `c`.`ShipToAddress2`        AS `ShipToAddress2`,
       `c`.`ShipToAddress3`        AS `ShipToAddress3`,
       `c`.`ShipToCity`            AS `ShipToCity`,
       `c`.`ShipToState`           AS `ShipToState`,
       `c`.`ShipToZipCode`         AS `ShipToZipCode`,
       `c`.`ShipToCountryCode`     AS `ShipToCountryCode`,
       `c`.`TelephoneNo`           AS `TelephoneNo`,
       `c`.`TelephoneExt`          AS `TelephoneExt`,
       `c`.`FaxNo`                 AS `FaxNo`,
       `c`.`EmailAddress`          AS `EmailAddress`,
       `c`.`ContactCode`           AS `ContactCode`,
       `c`.`SalespersonDivisionNo` AS `SalespersonDivisionNo`,
       `c`.`SalespersonNo`         AS `SalespersonNo`,
       `c`.`WarehouseCode`         AS `WarehouseCode`,
       `c`.`ResidentialAddress`    AS `ResidentialAddress`,
       `c`.`DateCreated`           AS `DateCreated`,
       `c`.`TimeCreated`           AS `TimeCreated`,
       `c`.`DateUpdated`           AS `DateUpdated`,
       `c`.`TimeUpdated`           AS `TimeUpdated`,
       `c`.`UserUpdatedKey`        AS `UserUpdatedKey`,
       `c`.`Reseller`              AS `Reseller`,
       `c`.`timestamp`             AS `timestamp`
FROM ((((`c2`.`so_shiptoaddress` `c` JOIN `c2`.`ar_customer` `ac` ON (`ac`.`Company` = `c`.`Company` AND
                                                                      `ac`.`ARDivisionNo` = `c`.`ARDivisionNo` AND
                                                                      `ac`.`CustomerNo` = `c`.`CustomerNo`)) JOIN `users`.`accounts` `a` ON (
        `c`.`Company` LIKE `a`.`Company` AND (`a`.`isRepAccount` = 0 AND `c`.`ARDivisionNo` LIKE `a`.`ARDivisionNo` AND
                                              `c`.`CustomerNo` LIKE `a`.`CustomerNo` OR `a`.`isRepAccount` = 1 AND
                                                                                        `c`.`SalespersonDivisionNo` LIKE `a`.`ARDivisionNo` AND
                                                                                        `c`.`SalespersonNo` LIKE `a`.`CustomerNo`))) LEFT JOIN `users`.`users` `u` ON (`u`.`id` = `a`.`userid` AND `u`.`active` = 1))
     LEFT JOIN `users`.`api_keys` `k`
               ON (`k`.`id` = `a`.`api_id`))
WHERE `a`.`userid` IS NOT NULL
   OR `a`.`api_id` IS NOT NULL;

