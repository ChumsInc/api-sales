CREATE
    DEFINER = steve@`%` FUNCTION checkUserAccountAccess(Company varchar(50), ARDivisionNo varchar(50),
                                                        CustomerNo varchar(50), UserID int) RETURNS int
BEGIN
    SELECT count(*) > 0 INTO @success
    FROM (
             SELECT c.Company, c.ARDivisionNo, c.CustomerNo
             FROM users.users u
                  INNER JOIN users.accounts a
                             ON a.userid = u.id
                  LEFT JOIN c2.ar_customer c
                            ON c.Company = a.Company
                                AND (c.ARDivisionNo like a.SalespersonDivisionNo  OR c.ARDivisionNo = a.ARDivisionNo)
                                AND (c.CustomerNo like a.SalespersonNo OR c.CustomerNo = c.CustomerNo)
                                AND c.CustomerStatus = 'A'
             WHERE u.id = UserID
				AND u.accountType = 1
               AND u.active = 1
               AND c.Company = Company
               AND c.ARDivisionNo = ARDivisionNo
               AND c.CustomerNo = CustomerNo

             UNION

             SELECT c.Company, c.ARDivisionNo, c.CustomerNo
             FROM users.users u
                  INNER JOIN users.accounts a
                             ON a.userid = u.id
                                 AND a.isRepAccount = 0
                  LEFT JOIN c2.ar_customer c
                            ON c.Company = a.Company
                                AND c.ARDivisionNo = a.ARDivisionNo
                                AND c.CustomerNo = a.CustomerNo
                                AND c.CustomerStatus = 'A'
             WHERE u.id = UserID
             AND u.accountType = 4
               AND u.active = 1
               AND c.Company = Company
               AND c.ARDivisionNo = ARDivisionNo
               AND c.CustomerNo = CustomerNo

             UNION

             SELECT c.Company, c.ARDivisionNo, c.CustomerNo
             FROM users.users u
                  INNER JOIN users.accounts a
                             ON a.userid = u.id
                                 AND a.isRepAccount = 1
                  INNER JOIN c2.ar_salesperson s
                             ON s.Company = a.Company
                                 AND s.SalespersonDivisionNo LIKE a.SalespersonDivisionNo
                                 AND s.SalespersonNo LIKE a.SalespersonNo
                                 AND ifnull(s.UDF_TERMINATED, 'N') <> 'Y'
                  INNER JOIN c2.ar_customer c
                             ON c.Company = s.Company
                                 AND c.SalespersonDivisionNo LIKE s.SalespersonDivisionNo
                                 AND c.SalespersonNo LIKE s.SalespersonNo
             WHERE u.id = UserID
             and u.accountType = 2
               AND u.active = 1
               AND c.Company = Company
               AND c.ARDivisionNo = ARDivisionNo
               AND c.CustomerNo = CustomerNo
         ) AS ownsAccount;
    RETURN @success;
END;

