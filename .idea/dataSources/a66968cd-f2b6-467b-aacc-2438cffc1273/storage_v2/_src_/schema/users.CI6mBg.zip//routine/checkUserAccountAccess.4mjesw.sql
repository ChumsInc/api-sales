CREATE
    DEFINER = steve@`%` FUNCTION checkUserAccountAccess(Company varchar(50), ARDivisionNo varchar(50),
                                                        CustomerNo varchar(50), UserID int) RETURNS int
BEGIN
    SELECT count(*) > 0 INTO @success
    FROM (
             SELECT c.*
             FROM users.users u
                  INNER JOIN users.accounts a
                             ON a.userid = u.id
                                 AND a.isRepAccount = 0
                  LEFT JOIN c2.ar_customer c
                            ON c.Company = a.Company
                                AND c.ARDivisionNo = a.ARDivisionNo
                                AND a.CustomerNo = c.CustomerNo
                                AND c.CustomerStatus = 'A'
             WHERE u.id = UserID
               AND u.active = 1
               AND c.Company = Company
               AND c.ARDivisionNo = ARDivisionNo
               AND c.CustomerNo = CustomerNo

             UNION

             SELECT c.*
             FROM users.users u
                  INNER JOIN users.accounts a
                             ON a.userid = u.id
                                 AND a.isRepAccount = 1
                  INNER JOIN c2.ar_salesperson s
                             ON s.Company = a.Company
                                 AND s.SalespersonDivisionNo LIKE a.SalespersonDivisionNo
                                 AND s.SalespersonNo LIKE a.SalespersonNo
                                 AND ifnull(s.UDF_TERMINATED, 'N') <> 'Y'
                  INNER JOIN c2.ar_customer c
                             ON c.Company = s.Company
                                 AND c.SalespersonDivisionNo LIKE s.SalespersonDivisionNo
                                 AND c.SalespersonNo LIKE s.SalespersonNo
             WHERE u.id = UserID
               AND u.active = 1
               AND c.Company = Company
               AND c.ARDivisionNo = ARDivisionNo
               AND c.CustomerNo = CustomerNo
         ) AS ownsAccount;
    RETURN @success;
END;

