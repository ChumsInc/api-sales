CREATE
    DEFINER = steve@localhost FUNCTION validation(Company varchar(50), ARDivisionNo varchar(50), CustomerNo varchar(50),
                                                  UserID int, ApiID int) RETURNS tinyint DETERMINISTIC
BEGIN
	SELECT count(*) > 0 into @success
	FROM c2.ar_customer c
	LEFT JOIN c2.so_shiptoaddress s
		ON s.Company = c.Company AND s.ARDivisionNo = c.ARDivisionNo AND s.CustomerNo = c.CustomerNo
	INNER JOIN users.accounts a 
	  	ON c.Company like a.Company 
	  	and (
	     	(c.ardivisionno like a.ARDivisionNo and c.customerno like a.CustomerNo and a.isRepAccount = 0)
		  OR (c.SalespersonDivisionNo like a.ARDivisionNo and c.salespersonno like a.CustomerNo and a.isRepAccount = 1)
	     OR (s.SalespersonDivisionNo like a.ARDivisionNo and s.salespersonno like a.CustomerNo and a.isRepAccount = 1)
		)
	LEFT JOIN users.users u on u.id = a.userid
	LEFT JOIN users.api_access api on api.id_api_access = a.api_id
	WHERE ((a.userid = UserID and u.active = 1) OR (a.api_id = ApiID and api.enabled = 1))
	AND c.Company LIKE Company
	AND (c.ardivisionno = ARDivisionNo OR (c.ardivisionno = ARDivisionNo and a.isRepAccount = 1))
	AND (c.customerno = CustomerNo OR (c.salespersonno = CustomerNo and a.isRepAccount = 1));	
	return @success;
END;

